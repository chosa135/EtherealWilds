import type { ConsumableMaster } from '../types';

/** 消耗品マスターデータ。 */
export const consumableMasters: Record<string, ConsumableMaster> = {
  vulnerary: {
    masterId: 'vulnerary',
    category: 'consumable',
    name: '傷薬',
    effect: 'heal',
    amount: 10,
    maxUses: 1,
  },
};
