export type Team = 'player' | 'enemy';
export type Tile = 'plain' | 'forest' | 'wall';
export type Phase = 'world' | 'player' | 'enemy' | 'rest' | 'result';
export type Mode = 'idle' | 'move' | 'menu' | 'equip' | 'targetAttack' | 'targetStrong' | 'confirmCombat';
export type StatKey = 'str' | 'mag' | 'skl' | 'spd' | 'def' | 'res';
export type AttackKind = 'normal' | 'strong';
export type WorldNodeType = 'start' | 'battle' | 'rest' | 'end';
export type RestMode = 'main' | 'repairTarget';
export type ConsumableEffect = 'heal';
export type DamageKind = 'physical' | 'magic';

export type Point = { x: number; y: number };

export type Weapon = {
  id: string;
  masterId: string;
  category: 'weapon';
  name: string;
  might: number;
  hit: number;
  rangeMin: number;
  rangeMax: number;
  maxDurability: number;
  durability: number;
  kind: DamageKind;
};

export type Consumable = {
  id: string;
  masterId: string;
  category: 'consumable';
  name: string;
  effect: ConsumableEffect;
  amount: number;
  uses: number;
};

export type Item = Weapon | Consumable;
export type InventorySlot = Item | null;

export type Unit = {
  id: string;
  name: string;
  cls: string;
  team: Team;
  x: number;
  y: number;
  move: number;
  level: number;
  exp: number;
  hp: number;
  maxHp: number;
  str: number;
  mag: number;
  skl: number;
  spd: number;
  def: number;
  res: number;
  growth: Record<StatKey, number>;
  inventory: InventorySlot[];
  equippedItemId: string | null;
  acted: boolean;
  unavailable: boolean;
  strongLeft: number;
};

export type MapDef = {
  name: string;
  tiles: string[];
  enemies: EnemyPlacement[];
};

export type EnemyPlacement = {
  id: string;
  enemyId: string;
  x: number;
  y: number;
};

export type WorldNode = {
  type: WorldNodeType;
  battleIndex?: number;
};

export type Button = {
  label: string;
  x: number;
  y: number;
  w: number;
  h: number;
  action: () => void;
  disabled?: boolean;
};

export type LevelUpPopup = {
  unitName: string;
  level: number;
  gains: Array<{ label: string; amount: number }>;
};

export type AttackSpec = {
  label: string;
  flatDamageBonus: number;
  skillDamageBonus: number;
  durabilityCost: number;
};

export type CombatIntent = {
  attacker: Unit;
  defender: Unit;
  firstAttackKind: AttackKind;
};

export type CombatLine = {
  label: string;
  actor: Unit;
  target: Unit;
  attackKind: AttackKind;
  damage: number;
  hit: number;
  durabilityCost: number;
  available: boolean;
  note?: string;
};

export type CombatPreview = {
  intent: CombatIntent;
  lines: CombatLine[];
  totalDurabilityCost: number;
};

export type WeaponMaster = Omit<Weapon, 'id' | 'durability'> & {
  maxDurability: number;
};

export type ConsumableMaster = Omit<Consumable, 'id' | 'uses'> & {
  maxUses: number;
};

export type InventoryTemplate =
  | { category: 'weapon'; masterId: string }
  | { category: 'consumable'; masterId: string }
  | null;

export type PlayerUnitMaster = {
  id: string;
  name: string;
  cls: string;
  move: number;
  level: number;
  exp: number;
  maxHp: number;
  str: number;
  mag: number;
  skl: number;
  spd: number;
  def: number;
  res: number;
  growth: Record<StatKey, number>;
  inventory: InventoryTemplate[];
  equippedSlot: number;
};

export type EnemyUnitMaster = {
  enemyId: string;
  name: string;
  cls: string;
  move: number;
  level: number;
  maxHp: number;
  str: number;
  mag: number;
  skl: number;
  spd: number;
  def: number;
  res: number;
  weaponId: string;
};
