type Team = 'player' | 'enemy';
type Tile = 'plain' | 'forest' | 'wall';
type Phase = 'world' | 'player' | 'enemy' | 'rest' | 'result';
type Mode = 'idle' | 'move' | 'menu' | 'target-attack' | 'target-strong' | 'confirm-combat';
type StatKey = 'str' | 'mag' | 'skl' | 'spd' | 'def' | 'res';
type AttackKind = 'normal' | 'strong';

type Weapon = {
  name: string;
  might: number;
  hit: number;
  rangeMin: number;
  rangeMax: number;
  maxDurability: number;
  durability: number;
  kind: 'physical' | 'magic';
};

type Unit = {
  id: string; name: string; cls: string; team: Team; x: number; y: number; move: number;
  level: number; exp: number; hp: number; maxHp: number;
  str: number; mag: number; skl: number; spd: number; def: number; res: number;
  growth: Record<StatKey, number>; weapon: Weapon; potion: number; acted: boolean; unavailable: boolean; strongLeft: number;
};

type MapDef = { name: string; tiles: string[]; enemies: Unit[] };
type WorldNode = { label: string; kind: 'start' | 'battle' | 'rest' | 'goal'; mapIndex?: number };
type Button = { label: string; x: number; y: number; w: number; h: number; action: () => void; disabled?: boolean };
type Point = { x: number; y: number };
type LevelUpPopup = { unitName: string; level: number; gains: Array<{ label: string; amount: number }> };
type CombatIntent = { attacker: Unit; defender: Unit; firstAttackKind: AttackKind };
type CombatLine = { label: string; actor: Unit; target: Unit; attackKind: AttackKind; damage: number; hit: number; durabilityCost: number; available: boolean; note?: string };
type CombatPreview = { intent: CombatIntent; lines: CombatLine[]; totalDurabilityCost: number };

const canvas = document.querySelector<HTMLCanvasElement>('#game')!;
const ctx = canvas.getContext('2d')!;

const TILE = 64;
const MAP_X = 28;
const MAP_Y = 28;
const PANEL_X = 600;
const PANEL_W = 550;
const W = 8;
const H = 6;
const STRONG_BASE_POWER = 3;

const statLabels: Record<StatKey, string> = { str: '力', mag: '魔力', skl: '技', spd: '速さ', def: '守備', res: '魔防' };

const makeWeapon = (name: string, might: number, hit: number, min: number, max: number, dura: number, kind: 'physical' | 'magic'): Weapon => ({
  name, might, hit, rangeMin: min, rangeMax: max, maxDurability: dura, durability: dura, kind,
});
const cloneUnit = (u: Unit): Unit => ({ ...u, growth: { ...u.growth }, weapon: { ...u.weapon } });

const playerBase: Unit[] = [
  { id: 'p1', name: 'リュカ', cls: '剣士', team: 'player', x: 1, y: 2, move: 4, level: 1, exp: 0,
    hp: 24, maxHp: 24, str: 7, mag: 0, skl: 7, spd: 8, def: 4, res: 3,
    growth: { str: 2, mag: 0, skl: 3, spd: 4, def: 1, res: 1 },
    weapon: makeWeapon('鉄の剣', 5, 92, 1, 1, 30, 'physical'), potion: 1, acted: false, unavailable: false, strongLeft: 2 },
  { id: 'p2', name: 'グレン', cls: '槍兵', team: 'player', x: 1, y: 3, move: 4, level: 1, exp: 0,
    hp: 28, maxHp: 28, str: 8, mag: 0, skl: 5, spd: 5, def: 7, res: 2,
    growth: { str: 2, mag: 0, skl: 2, spd: 2, def: 4, res: 1 },
    weapon: makeWeapon('鉄の槍', 6, 88, 1, 1, 30, 'physical'), potion: 1, acted: false, unavailable: false, strongLeft: 2 },
  { id: 'p3', name: 'エナ', cls: '弓兵', team: 'player', x: 0, y: 2, move: 4, level: 1, exp: 0,
    hp: 21, maxHp: 21, str: 6, mag: 0, skl: 8, spd: 7, def: 3, res: 3,
    growth: { str: 2, mag: 0, skl: 4, spd: 3, def: 1, res: 1 },
    weapon: makeWeapon('鉄の弓', 5, 87, 2, 2, 25, 'physical'), potion: 1, acted: false, unavailable: false, strongLeft: 2 },
  { id: 'p4', name: 'ミロ', cls: '魔道士', team: 'player', x: 0, y: 3, move: 4, level: 1, exp: 0,
    hp: 20, maxHp: 20, str: 0, mag: 7, skl: 6, spd: 6, def: 2, res: 6,
    growth: { str: 0, mag: 4, skl: 2, spd: 2, def: 1, res: 3 },
    weapon: makeWeapon('魔導書', 5, 90, 1, 2, 25, 'magic'), potion: 1, acted: false, unavailable: false, strongLeft: 2 },
];

function enemy(id: string, name: string, cls: string, x: number, y: number, hp: number, str: number, mag: number, skl: number, spd: number, def: number, res: number, weapon: Weapon): Unit {
  return { id, name, cls, team: 'enemy', x, y, move: 3, level: 1, exp: 0, hp, maxHp: hp, str, mag, skl, spd, def, res,
    growth: { str: 0, mag: 0, skl: 0, spd: 0, def: 0, res: 0 }, weapon, potion: 0, acted: false, unavailable: false, strongLeft: 0 };
}

const maps: MapDef[] = [
  { name: '幽樹海・浅層入口', tiles: ['........', '..f.....', '....#...', '.f......', '.....f..', '........'], enemies: [
    enemy('e1', '樹海の魔物', '魔物', 5, 1, 20, 7, 0, 4, 4, 4, 1, makeWeapon('爪', 4, 88, 1, 1, 99, 'physical')),
    enemy('e2', '弓盗賊', '弓兵', 6, 4, 17, 6, 0, 5, 5, 2, 2, makeWeapon('粗末な弓', 4, 86, 2, 2, 99, 'physical')),
  ]},
  { name: '幽樹海・苔むす小径', tiles: ['..f.....', '..f..#..', '........', '.ff.....', '....f...', '........'], enemies: [
    enemy('e3', '剣盗賊', '剣兵', 5, 1, 21, 7, 0, 5, 6, 4, 2, makeWeapon('粗末な剣', 4, 90, 1, 1, 99, 'physical')),
    enemy('e4', '樹海の魔物', '魔物', 6, 3, 24, 8, 0, 4, 4, 5, 1, makeWeapon('爪', 5, 88, 1, 1, 99, 'physical')),
    enemy('e5', '呪草', '魔物', 5, 5, 18, 0, 7, 5, 4, 2, 5, makeWeapon('瘴気', 5, 90, 1, 2, 99, 'magic')),
  ]},
  { name: '幽樹海・倒木の広場', tiles: ['........', '.f..##..', '.f......', '....f...', '...##...', '........'], enemies: [
    enemy('e6', '斧盗賊', '斧兵', 5, 0, 23, 9, 0, 3, 4, 4, 1, makeWeapon('粗末な斧', 7, 78, 1, 1, 99, 'physical')),
    enemy('e7', '弓盗賊', '弓兵', 6, 2, 18, 7, 0, 5, 5, 3, 2, makeWeapon('粗末な弓', 5, 86, 2, 2, 99, 'physical')),
    enemy('e8', '樹海の魔物', '魔物', 5, 5, 25, 8, 0, 4, 5, 5, 2, makeWeapon('爪', 5, 88, 1, 1, 99, 'physical')),
  ]},
  { name: '幽樹海・幽金の細脈', tiles: ['..f.....', '....#...', '.f..#...', '........', '...ff...', '........'], enemies: [
    enemy('e9', '剣盗賊', '剣兵', 5, 1, 23, 8, 0, 6, 6, 4, 2, makeWeapon('粗末な剣', 5, 90, 1, 1, 99, 'physical')),
    enemy('e10', '呪草', '魔物', 6, 2, 20, 0, 8, 5, 4, 2, 6, makeWeapon('瘴気', 5, 90, 1, 2, 99, 'magic')),
    enemy('e11', '樹海の魔物', '魔物', 6, 5, 27, 9, 0, 5, 5, 5, 2, makeWeapon('爪', 6, 88, 1, 1, 99, 'physical')),
  ]},
  { name: '幽樹海・浅層最奥', tiles: ['........', '..f..#..', '..f.....', '....ff..', '.#......', '........'], enemies: [
    enemy('e12', '斧盗賊', '斧兵', 5, 0, 24, 9, 0, 3, 4, 4, 1, makeWeapon('粗末な斧', 7, 78, 1, 1, 99, 'physical')),
    enemy('e13', '弓盗賊', '弓兵', 6, 2, 19, 7, 0, 5, 5, 3, 2, makeWeapon('粗末な弓', 5, 86, 2, 2, 99, 'physical')),
    enemy('e14', '幽金を喰らうもの', '強敵', 6, 5, 34, 10, 0, 6, 5, 7, 3, makeWeapon('大爪', 7, 88, 1, 1, 99, 'physical')),
  ]},
];


const worldNodes: WorldNode[] = [
  { label: '探索開始', kind: 'start' },
  { label: '浅層入口', kind: 'battle', mapIndex: 0 },
  { label: '苔むす小径', kind: 'battle', mapIndex: 1 },
  { label: '休憩所', kind: 'rest' },
  { label: '倒木の広場', kind: 'battle', mapIndex: 2 },
  { label: '幽金の細脈', kind: 'battle', mapIndex: 3 },
  { label: '休憩所', kind: 'rest' },
  { label: '浅層最奥', kind: 'battle', mapIndex: 4 },
  { label: '帰還', kind: 'goal' },
];

let players = playerBase.map(cloneUnit);
let enemies: Unit[] = [];
let mapIndex = 0;
let worldIndex = 0;
let restActionsLeft = 0;
let phase: Phase = 'world';
let mode: Mode = 'idle';
let selected: Unit | null = null;
let selectedOrigin: Point | null = null;
let reachable: Point[] = [];
let targets: Unit[] = [];
let buttons: Button[] = [];
let logs: string[] = [];
let currentTiles: Tile[][] = [];
let hover: Point | null = null;
let runCleared = false;
let levelUpPopups: LevelUpPopup[] = [];
let pendingCombat: CombatIntent | null = null;

function log(msg: string) { logs.unshift(msg); logs = logs.slice(0, 7); }
function parseTiles(def: MapDef): Tile[][] { return def.tiles.map(row => row.split('').map(c => c === 'f' ? 'forest' : c === '#' ? 'wall' : 'plain')); }
function startMap(index: number) {
  mapIndex = index; currentTiles = parseTiles(maps[index]); enemies = maps[index].enemies.map(cloneUnit);
  const starts = [{ x: 1, y: 2 }, { x: 1, y: 3 }, { x: 0, y: 2 }, { x: 0, y: 3 }];
  players.forEach((p, i) => { p.x = starts[i].x; p.y = starts[i].y; p.acted = p.unavailable; p.strongLeft = 2; });
  phase = 'player'; mode = 'idle'; selected = null; selectedOrigin = null; reachable = []; targets = []; pendingCombat = null;
  log(`【${maps[index].name}】探索開始`);
}


function enterNextWorldNode() {
  if (worldIndex >= worldNodes.length - 1) return;
  worldIndex += 1;
  const node = worldNodes[worldIndex];
  if (node.kind === 'battle' && node.mapIndex !== undefined) {
    startMap(node.mapIndex);
  } else if (node.kind === 'rest') {
    phase = 'rest';
    mode = 'idle';
    selected = null;
    selectedOrigin = null;
    reachable = [];
    targets = [];
    pendingCombat = null;
    restActionsLeft = 2;
    log('休憩所に到着した。2回行動できます');
  } else if (node.kind === 'goal') {
    phase = 'result';
    runCleared = true;
    log('幽樹海・浅層探索 完了');
  }
}

function returnToWorldAfterBattle() {
  phase = 'world';
  mode = 'idle';
  selected = null;
  selectedOrigin = null;
  reachable = [];
  targets = [];
  pendingCombat = null;
  log('ワールドマップに戻った');
}

function completeRestIfNeeded() {
  if (restActionsLeft <= 0) {
    restActionsLeft = 0;
    phase = 'world';
    log('休憩所を出発できるようになった');
  }
}

function inBounds(x: number, y: number) { return x >= 0 && y >= 0 && x < W && y < H; }
function tileAt(x: number, y: number) { return currentTiles[y]?.[x] ?? 'wall'; }
function moveCost(x: number, y: number) { const t = tileAt(x, y); return t === 'wall' ? 999 : t === 'forest' ? 2 : 1; }
function livingPlayers() { return players.filter(u => !u.unavailable && u.hp > 0); }
function activePlayers() { return livingPlayers().filter(u => !u.acted); }
function livingEnemies() { return enemies.filter(u => u.hp > 0); }
function allUnits() { return [...livingPlayers(), ...livingEnemies()]; }
function unitAt(x: number, y: number): Unit | null { return allUnits().find(u => u.x === x && u.y === y) ?? null; }
function distance(a: Point, b: Point) { return Math.abs(a.x - b.x) + Math.abs(a.y - b.y); }
function pointKey(p: Point) { return `${p.x},${p.y}`; }
function inRange(attacker: Unit, target: Unit) { const d = distance(attacker, target); return d >= attacker.weapon.rangeMin && d <= attacker.weapon.rangeMax; }

function computeAttackCellsFromPositions(u: Unit, positions: Point[]): Point[] {
  const cells = new Map<string, Point>();
  for (const pos of positions) for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    if (tileAt(x, y) === 'wall') continue;
    const d = distance(pos, { x, y });
    if (d >= u.weapon.rangeMin && d <= u.weapon.rangeMax) cells.set(`${x},${y}`, { x, y });
  }
  return [...cells.values()];
}
function getPreviewRanges(u: Unit, allowMove: boolean) {
  const moveCells = allowMove ? computeReachable(u) : [{ x: u.x, y: u.y }];
  const moveSet = new Set(moveCells.map(pointKey));
  const attackCells = computeAttackCellsFromPositions(u, moveCells).filter(p => !moveSet.has(pointKey(p)));
  return { moveCells, attackCells };
}
function computeReachable(u: Unit): Point[] {
  const seen = new Map<string, number>();
  const queue: Array<{ x: number; y: number; cost: number }> = [{ x: u.x, y: u.y, cost: 0 }];
  seen.set(`${u.x},${u.y}`, 0);
  while (queue.length) {
    const cur = queue.shift()!;
    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nx = cur.x + dx, ny = cur.y + dy;
      if (!inBounds(nx, ny) || tileAt(nx, ny) === 'wall') continue;
      const occ = unitAt(nx, ny);
      if (occ && occ.id !== u.id) continue;
      const nextCost = cur.cost + moveCost(nx, ny);
      if (nextCost > u.move) continue;
      const key = `${nx},${ny}`;
      if (!seen.has(key) || nextCost < seen.get(key)!) { seen.set(key, nextCost); queue.push({ x: nx, y: ny, cost: nextCost }); }
    }
  }
  return [...seen.keys()].map(k => { const [x, y] = k.split(',').map(Number); return { x, y }; });
}

function canStand(x: number, y: number) { return reachable.some(p => p.x === x && p.y === y); }
function isPlayer(u: Unit | null): u is Unit { return !!u && u.team === 'player'; }
function clamp(n: number, min: number, max: number) { return Math.max(min, Math.min(max, n)); }

function attackSpec(kind: AttackKind, attacker: Unit, defender: Unit) {
  const skillBonus = kind === 'strong' ? Math.max(attacker.skl - defender.skl, 0) : 0;
  return {
    kind,
    label: kind === 'strong' ? '強撃' : '攻撃',
    flatDamageBonus: kind === 'strong' ? STRONG_BASE_POWER : 0,
    skillDamageBonus: skillBonus,
    durabilityCost: kind === 'strong' ? 3 : 1,
  };
}
function baseAttackPower(u: Unit) { return (u.weapon.kind === 'magic' ? u.mag : u.str) + u.weapon.might; }
function defenseAgainst(attacker: Unit, defender: Unit) { return attacker.weapon.kind === 'magic' ? defender.res : defender.def; }
function damageFor(attacker: Unit, defender: Unit, kind: AttackKind) {
  const spec = attackSpec(kind, attacker, defender);
  const normalDamage = Math.max(1, baseAttackPower(attacker) - defenseAgainst(attacker, defender));
  return normalDamage + spec.flatDamageBonus + spec.skillDamageBonus;
}
function hitRate(attacker: Unit, defender: Unit) { return clamp(attacker.weapon.hit + attacker.skl * 2 - defender.spd * 2, 0, 100); }
function roll2RN(hit: number): boolean { return (Math.random() * 100 + Math.random() * 100) / 2 < hit; }
function canDouble(attacker: Unit, defender: Unit) { return attacker.spd >= defender.spd + 4; }
function canUseWeaponForKind(u: Unit, kind: AttackKind) { return u.weapon.durability >= attackSpec(kind, u, u).durabilityCost; }
function addCombatLine(lines: CombatLine[], label: string, actor: Unit, target: Unit, kind: AttackKind, available: boolean, note?: string) {
  lines.push({ label, actor, target, attackKind: kind, damage: damageFor(actor, target, kind), hit: hitRate(actor, target), durabilityCost: attackSpec(kind, actor, target).durabilityCost, available, note });
}
function buildCombatPreview(intent: CombatIntent): CombatPreview {
  const { attacker, defender, firstAttackKind } = intent;
  const lines: CombatLine[] = [];
  let remainingDurability = attacker.weapon.durability;

  const firstCost = attackSpec(firstAttackKind, attacker, defender).durabilityCost;
  const firstAvailable = remainingDurability >= firstCost;
  addCombatLine(
    lines,
    '自分の攻撃',
    attacker,
    defender,
    firstAttackKind,
    firstAvailable,
    firstAvailable
      ? firstAttackKind === 'strong' ? `技差+${attackSpec('strong', attacker, defender).skillDamageBonus}` : undefined
      : '耐久不足',
  );
  if (firstAvailable) remainingDurability -= firstCost;

  const defenderMayCounter = inRange(defender, attacker);
  if (defenderMayCounter) addCombatLine(lines, '敵の反撃', defender, attacker, 'normal', true, '敵が生存時');
  else addCombatLine(lines, '敵の反撃', defender, attacker, 'normal', false, '射程外');

  if (canDouble(attacker, defender)) {
    const followCost = attackSpec('normal', attacker, defender).durabilityCost;
    const followAvailable = remainingDurability >= followCost;
    addCombatLine(lines, '自分の追撃', attacker, defender, 'normal', followAvailable, followAvailable ? '敵が生存時' : '耐久不足');
  }
  const totalDurabilityCost = lines.filter(l => l.actor.id === attacker.id && l.available).reduce((sum, l) => sum + l.durabilityCost, 0);
  return { intent, lines, totalDurabilityCost };
}

function addExp(u: Unit, amount: number) {
  if (u.team !== 'player' || u.unavailable) return;
  u.exp += amount;
  while (u.exp >= 100) { u.exp -= 100; levelUp(u); }
}
function weightedStat(growth: Record<StatKey, number>): StatKey {
  const entries = Object.entries(growth) as Array<[StatKey, number]>;
  const total = entries.reduce((sum, [, w]) => sum + Math.max(0, w), 0);
  let r = Math.random() * total;
  for (const [k, w] of entries) { r -= Math.max(0, w); if (r <= 0) return k; }
  return 'str';
}
function levelUp(u: Unit) {
  u.level += 1; u.maxHp += 1; u.hp += 1;
  const gains: Partial<Record<StatKey, number>> = {};
  for (let i = 0; i < 3; i++) { const k = weightedStat(u.growth); u[k] += 1; gains[k] = (gains[k] ?? 0) + 1; }
  const gainedStats = Object.entries(gains).map(([k, v]) => ({ label: statLabels[k as StatKey], amount: v as number }));
  log(`${u.name} Lv${u.level}: HP+1 / ${gainedStats.map(g => `${g.label}+${g.amount}`).join(' / ')}`);
  levelUpPopups.push({ unitName: u.name, level: u.level, gains: [{ label: 'HP', amount: 1 }, ...gainedStats] });
}

function consumeDurability(u: Unit, amount: number) { if (u.team === 'player') u.weapon.durability = Math.max(0, u.weapon.durability - amount); }
function executeStrike(actor: Unit, target: Unit, kind: AttackKind): boolean {
  const spec = attackSpec(kind, actor, target);
  if (actor.weapon.durability < spec.durabilityCost) { log(`${actor.name}の武器耐久が足りない`); return false; }
  consumeDurability(actor, spec.durabilityCost);
  const hit = hitRate(actor, target);
  if (roll2RN(hit)) {
    const dmg = damageFor(actor, target, kind);
    target.hp = Math.max(0, target.hp - dmg);
    const detail = kind === 'strong' ? `（技差+${spec.skillDamageBonus}）` : '';
    log(`${actor.name}の${spec.label}: ${target.name}に${dmg}ダメージ ${detail}`);
  } else {
    log(`${actor.name}の${spec.label}: ${target.name}に外れた（命中${hit}%）`);
  }
  return true;
}
function doCombat(intent: CombatIntent) {
  const { attacker, defender, firstAttackKind } = intent;
  if (attacker.team === 'player' && firstAttackKind === 'strong') attacker.strongLeft -= 1;

  executeStrike(attacker, defender, firstAttackKind);
  if (defender.hp <= 0) defeatUnit(defender);

  if (defender.hp > 0 && attacker.hp > 0 && inRange(defender, attacker)) {
    executeStrike(defender, attacker, 'normal');
    if (attacker.hp <= 0) defeatUnit(attacker);
  }

  if (attacker.hp > 0 && defender.hp > 0 && canDouble(attacker, defender)) {
    executeStrike(attacker, defender, 'normal');
    if (defender.hp <= 0) defeatUnit(defender);
  }

  if (attacker.team === 'player') addExp(attacker, 5);
  if (defender.hp <= 0 && attacker.team === 'player') addExp(attacker, 30);
  pendingCombat = null;
  checkMapEnd();
}
function defeatUnit(unit: Unit) {
  if (unit.team === 'player') { unit.unavailable = true; unit.acted = true; log(`${unit.name}は戦闘不可になり、後方へ撤退した`); }
  else log(`${unit.name}を撃破した`);
}

function finishAction() {
  if (selected) selected.acted = true;
  selected = null; selectedOrigin = null; reachable = []; targets = []; pendingCombat = null; mode = 'idle';
  if (phase === 'player' && activePlayers().length === 0) beginEnemyTurn();
}
function beginEnemyTurn() {
  phase = 'enemy'; mode = 'idle'; selected = null; selectedOrigin = null; reachable = []; targets = []; pendingCombat = null;
  setTimeout(runEnemyTurn, 250);
}
function endPlayerTurn() {
  if (phase !== 'player') return;
  livingPlayers().forEach(p => { if (!p.acted) p.acted = true; });
  selected = null; selectedOrigin = null; reachable = []; targets = []; pendingCombat = null; mode = 'idle';
  log('ターン終了：行動可能な味方は待機した');
  beginEnemyTurn();
}
function runEnemyTurn() {
  for (const e of livingEnemies()) {
    const targetsNow = livingPlayers();
    if (targetsNow.length === 0) break;
    let target = targetsNow.filter(p => inRange(e, p)).sort((a, b) => a.hp - b.hp)[0];
    if (!target) { moveEnemyToward(e, targetsNow); target = targetsNow.filter(p => inRange(e, p)).sort((a, b) => a.hp - b.hp)[0]; }
    if (target) doCombat({ attacker: e, defender: target, firstAttackKind: 'normal' });
  }
  if (phase !== 'result' && phase !== 'rest' && phase !== 'world') { livingPlayers().forEach(p => { p.acted = false; p.strongLeft = 2; }); phase = 'player'; log('自軍フェイズ'); }
}
function moveEnemyToward(e: Unit, targetsNow: Unit[]) {
  const reach = computeReachable(e);
  const occupied = new Set(allUnits().filter(u => u.id !== e.id).map(u => `${u.x},${u.y}`));
  let best = { x: e.x, y: e.y }, bestScore = 999;
  for (const p of reach) { if (occupied.has(`${p.x},${p.y}`)) continue; const score = Math.min(...targetsNow.map(t => distance(p, t))); if (score < bestScore) { best = p; bestScore = score; } }
  e.x = best.x; e.y = best.y;
}
function checkMapEnd() {
  if (livingEnemies().length === 0) {
    log(`【${maps[mapIndex].name}】敵全滅`);
    returnToWorldAfterBattle();
  } else if (livingPlayers().length === 0) {
    phase = 'result';
    runCleared = false;
    log('探索隊は撤退した');
  }
}

function consumeRestAction() {
  restActionsLeft -= 1;
  completeRestIfNeeded();
}

function chooseRest(action: 'rest' | 'revive' | 'train' | 'repair', target?: Unit) {
  if (phase !== 'rest' || restActionsLeft <= 0) return;

  if (action === 'rest') {
    for (const p of livingPlayers()) p.hp = Math.min(p.maxHp, p.hp + Math.ceil(p.maxHp * 0.5));
    log('休憩所: 休息で出撃可能な全員のHPを50%回復した');
    consumeRestAction();
    return;
  }

  if (action === 'revive') {
    const revived = players.find(p => p.unavailable);
    if (!revived) { log('復帰が必要な隊員はいない'); return; }
    revived.unavailable = false;
    revived.hp = Math.max(1, Math.ceil(revived.maxHp * 0.5));
    log(`休憩所: ${revived.name}を復帰させた`);
    consumeRestAction();
    return;
  }

  if (action === 'train') {
    for (const p of livingPlayers()) addExp(p, 30);
    log('休憩所: 出撃可能な全員が鍛錬した（EXP+30）');
    consumeRestAction();
    return;
  }

  if (action === 'repair') {
    if (!target) return;
    const recover = Math.ceil(target.weapon.maxDurability * 0.5);
    target.weapon.durability = Math.min(target.weapon.maxDurability, target.weapon.durability + recover);
    log(`休憩所: ${target.name}の${target.weapon.name}を修繕した`);
    consumeRestAction();
  }
}
function cancelSelection() {
  if (selected && selectedOrigin) { selected.x = selectedOrigin.x; selected.y = selectedOrigin.y; }
  selected = null; selectedOrigin = null; reachable = []; targets = []; pendingCombat = null; mode = 'idle'; log('選択を解除した');
}
function returnToMenu() { targets = []; pendingCombat = null; mode = 'menu'; }
function usePotion(u: Unit) {
  if (u.potion <= 0) { log('傷薬がない'); return; }
  if (u.hp >= u.maxHp) { log('HPは満タン'); return; }
  u.potion -= 1; u.hp = Math.min(u.maxHp, u.hp + 10); log(`${u.name}は傷薬で回復した`); finishAction();
}

function buildButtons() {
  buttons = [];
  const bx = PANEL_X + 16;
  let by = 318;
  const add = (label: string, action: () => void, disabled = false, x = bx, w = 210) => { buttons.push({ label, x, y: by, w, h: 34, action, disabled }); by += 39; };
  const addFixed = (label: string, x: number, y: number, w: number, action: () => void, disabled = false) => { buttons.push({ label, x, y, w, h: 34, action, disabled }); };
  if (phase === 'player') addFixed('ターン終了', PANEL_X + 310, 78, 128, () => endPlayerTurn(), activePlayers().length === 0);
  if (phase === 'world') {
    const next = worldNodes[worldIndex + 1];
    add(next ? `次へ：${next.label}` : '次へ', () => enterNextWorldNode(), !next, bx, 260);
    return;
  }
  if (phase === 'rest') {
    by = 246;
    const hasDown = players.some(p => p.unavailable);
    add(`休息：全員HP+50%（残り${restActionsLeft}）`, () => chooseRest('rest'), restActionsLeft <= 0, bx, 270);
    add('復帰：戦闘不能者1人 HP50%', () => chooseRest('revive'), !hasDown || restActionsLeft <= 0, bx, 270);
    add('鍛錬：全員EXP+30', () => chooseRest('train'), restActionsLeft <= 0, bx, 270);
    for (const p of players) {
      add(`修繕：${p.name}の${p.weapon.name}`, () => chooseRest('repair', p), restActionsLeft <= 0 || p.weapon.durability >= p.weapon.maxDurability, bx, 270);
    }
    return;
  }
  if (phase === 'result') { add('最初から遊ぶ', () => resetRun()); return; }
  if (mode === 'move' && selected) add('やめる', () => cancelSelection());
  if (mode === 'menu' && selected) {
    const attackable = livingEnemies().some(e => inRange(selected!, e));
    add('攻撃', () => selectTargets(false), !attackable || selected.weapon.durability < 1);
    add(`強撃 ${selected.strongLeft}/2`, () => selectTargets(true), !attackable || selected.strongLeft <= 0 || selected.weapon.durability < 3);
    add(`傷薬 ${selected.potion}`, () => usePotion(selected!), selected.potion <= 0 || selected.hp >= selected.maxHp);
    add('待機', () => finishAction());
    add('やめる', () => cancelSelection());
  }
  if ((mode === 'target-attack' || mode === 'target-strong') && selected) add('やめる', () => returnToMenu());
  if (mode === 'confirm-combat' && pendingCombat) { const preview = buildCombatPreview(pendingCombat); add('戦う', () => { doCombat(pendingCombat!); finishAction(); }, !preview.lines[0]?.available); add('やめる', () => returnToMenu()); }
}
function selectTargets(strong: boolean) { if (!selected) return; targets = livingEnemies().filter(e => inRange(selected!, e)); mode = strong ? 'target-strong' : 'target-attack'; log('攻撃対象を選択してください'); }
function resetRun() { players = playerBase.map(cloneUnit); logs = []; levelUpPopups = []; pendingCombat = null; worldIndex = 0; restActionsLeft = 0; phase = 'world'; mode = 'idle'; selected = null; selectedOrigin = null; reachable = []; targets = []; runCleared = false; log('探索準備完了'); }
function screenToCell(mx: number, my: number): Point | null { const x = Math.floor((mx - MAP_X) / TILE); const y = Math.floor((my - MAP_Y) / TILE); return inBounds(x, y) ? { x, y } : null; }

canvas.addEventListener('mousemove', e => { const rect = canvas.getBoundingClientRect(); hover = screenToCell(e.clientX - rect.left, e.clientY - rect.top); });
function isPopupOpen() { return levelUpPopups.length > 0; }
canvas.addEventListener('click', e => {
  const rect = canvas.getBoundingClientRect(); const mx = e.clientX - rect.left; const my = e.clientY - rect.top;
  if (isPopupOpen()) { levelUpPopups.shift(); return; }
  for (const b of buttons) if (mx >= b.x && mx <= b.x + b.w && my >= b.y && my <= b.y + b.h) { if (!b.disabled) b.action(); return; }
  if (phase !== 'player') return;
  const cell = screenToCell(mx, my); if (!cell) return;
  const u = unitAt(cell.x, cell.y);
  if (mode === 'idle') { if (isPlayer(u) && !u.acted && !u.unavailable) { selected = u; selectedOrigin = { x: u.x, y: u.y }; reachable = computeReachable(u); mode = 'move'; log(`${u.name}を選択`); } return; }
  if (mode === 'move') { if (canStand(cell.x, cell.y) && selected) { selected.x = cell.x; selected.y = cell.y; mode = 'menu'; return; } cancelSelection(); return; }
  if ((mode === 'target-attack' || mode === 'target-strong') && selected) {
    const target = targets.find(t => t.x === cell.x && t.y === cell.y);
    if (target) { pendingCombat = { attacker: selected, defender: target, firstAttackKind: mode === 'target-strong' ? 'strong' : 'normal' }; mode = 'confirm-combat'; }
    else returnToMenu();
  }
});

function draw() { ctx.fillStyle = '#151916'; ctx.fillRect(0, 0, canvas.width, canvas.height); if (phase === 'player' || phase === 'enemy') { drawMap(); drawUnits(); } else { drawWorldMap(); } drawPanel(); drawLevelUpPopup(); requestAnimationFrame(draw); }

function drawWorldMap() {
  ctx.fillStyle = '#172019';
  ctx.fillRect(MAP_X, MAP_Y, W * TILE, H * TILE);
  drawText('幽樹海 探索路', MAP_X + 170, MAP_Y + 38, '#f0ead2', 24);
  const startX = MAP_X + 46;
  const y = MAP_Y + 190;
  const gap = 54;
  for (let i = 0; i < worldNodes.length; i++) {
    const node = worldNodes[i];
    const x = startX + i * gap;
    if (i > 0) {
      ctx.strokeStyle = i <= worldIndex ? '#cde6c7' : '#59645c';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(x - gap + 18, y);
      ctx.lineTo(x - 18, y);
      ctx.stroke();
    }
    ctx.beginPath();
    ctx.arc(x, y, 18, 0, Math.PI * 2);
    ctx.fillStyle = i < worldIndex ? '#6fa66d' : i === worldIndex ? '#fff36a' : node.kind === 'rest' ? '#5e8fc2' : '#344d36';
    ctx.fill();
    ctx.strokeStyle = '#111';
    ctx.stroke();
    drawText(node.kind === 'battle' ? '戦' : node.kind === 'rest' ? '休' : node.kind === 'goal' ? '帰' : '始', x - 8, y + 6, '#111', 15);
    drawText(node.label, x - 28, y + 42, i === worldIndex ? '#fff36a' : '#e8e8e8', 12);
  }
  const current = worldNodes[worldIndex];
  const next = worldNodes[worldIndex + 1];
  drawText(`現在地：${current.label}`, MAP_X + 34, MAP_Y + 300, '#ffffff', 18);
  drawText(next ? `次のマス：${next.label}` : '次のマス：なし', MAP_X + 34, MAP_Y + 330, '#cde6c7', 18);
  if (phase === 'rest') drawText(`休憩所：残り行動 ${restActionsLeft}`, MAP_X + 34, MAP_Y + 362, '#d8e7ff', 18);
}

function drawMap() {
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const sx = MAP_X + x * TILE, sy = MAP_Y + y * TILE; const t = tileAt(x, y);
    ctx.fillStyle = t === 'forest' ? '#29452d' : t === 'wall' ? '#4a4a4a' : '#253326'; ctx.fillRect(sx, sy, TILE, TILE);
    ctx.strokeStyle = '#556052'; ctx.strokeRect(sx, sy, TILE, TILE);
    if (t === 'forest') drawText('森', sx + 20, sy + 38, '#cfe8ca', 16); if (t === 'wall') drawText('岩', sx + 20, sy + 38, '#ddd', 16);
  }
  drawRangePreview();
  if (mode === 'target-attack' || mode === 'target-strong' || mode === 'confirm-combat') for (const t of targets) overlayCell(t.x, t.y, 'rgba(255,90,80,0.42)');
  if (hover) overlayCell(hover.x, hover.y, 'rgba(255,255,255,0.12)');
}
function drawRangePreview() {
  const hoverUnit = hover ? unitAt(hover.x, hover.y) : null; const previewUnit = selected ?? hoverUnit;
  if (!previewUnit || previewUnit.unavailable || previewUnit.hp <= 0) return;
  const allowMove = selected?.id === previewUnit.id ? mode === 'move' : true;
  const ranges = selected?.id === previewUnit.id && mode === 'move'
    ? (() => { const moveSet = new Set(reachable.map(pointKey)); return { moveCells: reachable, attackCells: computeAttackCellsFromPositions(previewUnit, reachable).filter(p => !moveSet.has(pointKey(p))) }; })()
    : getPreviewRanges(previewUnit, allowMove);
  for (const p of ranges.attackCells) overlayCell(p.x, p.y, 'rgba(255,90,80,0.23)');
  for (const p of ranges.moveCells) overlayCell(p.x, p.y, 'rgba(80,150,255,0.28)');
}
function overlayCell(x: number, y: number, color: string) { ctx.fillStyle = color; ctx.fillRect(MAP_X + x * TILE, MAP_Y + y * TILE, TILE, TILE); }
function drawUnits() {
  for (const u of [...livingEnemies(), ...livingPlayers()]) {
    const sx = MAP_X + u.x * TILE + TILE / 2, sy = MAP_Y + u.y * TILE + TILE / 2;
    ctx.beginPath(); ctx.arc(sx, sy, 22, 0, Math.PI * 2); ctx.fillStyle = u.team === 'player' ? '#7fb7ff' : '#ff7f7f'; ctx.fill();
    ctx.strokeStyle = selected?.id === u.id ? '#fff36a' : '#101010'; ctx.lineWidth = selected?.id === u.id ? 4 : 2; ctx.stroke();
    drawText(u.name.slice(0, 2), sx - 16, sy + 5, '#111', 14);
    const barW = 46; ctx.fillStyle = '#222'; ctx.fillRect(sx - barW / 2, sy + 27, barW, 6); ctx.fillStyle = '#66e083'; ctx.fillRect(sx - barW / 2, sy + 27, barW * (u.hp / u.maxHp), 6);
    drawText(`${u.hp}`, sx - 10, sy + 48, '#fff', 12);
    if (u.acted && u.team === 'player') { ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.arc(sx, sy, 23, 0, Math.PI * 2); ctx.fill(); }
  }
}
function drawPanel() {
  ctx.fillStyle = '#20271f'; ctx.fillRect(PANEL_X, 0, PANEL_W, canvas.height);
  drawText('Ethereal Wilds Prototype', PANEL_X + 16, 32, '#f0ead2', 22);
  drawText(phase === 'player' || phase === 'enemy' ? `${maps[mapIndex].name} (${mapIndex + 1}/${maps.length})` : `ワールドマップ ${worldIndex + 1}/${worldNodes.length}`, PANEL_X + 16, 62, '#cde6c7', 16);
  drawText(`フェイズ: ${phaseLabel()}`, PANEL_X + 16, 88, '#ffffff', 16);

  const info = selected ?? (hover ? unitAt(hover.x, hover.y) ?? null : null);
  let y = 124;
  if (info) {
    drawText(`${info.name} / ${info.cls}`, PANEL_X + 16, y, '#fff36a', 20); y += 28;
    drawText(`Lv${info.level} EXP${info.exp}  HP ${info.hp}/${info.maxHp}`, PANEL_X + 16, y, '#fff', 16); y += 24;
    drawText(`力${info.str} 魔${info.mag} 技${info.skl} 速${info.spd}`, PANEL_X + 16, y, '#fff', 16); y += 24;
    drawText(`守${info.def} 魔防${info.res} 移${info.move}`, PANEL_X + 16, y, '#fff', 16); y += 24;
    drawText(`${info.weapon.name} 威力${info.weapon.might} 命中${info.weapon.hit} 射程${info.weapon.rangeMin}-${info.weapon.rangeMax}`, PANEL_X + 16, y, '#d8e7ff', 16); y += 24;
    drawText(`耐久 ${info.weapon.durability}/${info.weapon.maxDurability}  強撃 ${info.strongLeft}/2`, PANEL_X + 16, y, '#d8e7ff', 16); y += 24;
    if (info.unavailable) drawText('状態: 戦闘不可', PANEL_X + 16, y, '#ff9b9b', 16);
  } else drawText('自軍ユニットを選択してください', PANEL_X + 16, y, '#ddd', 16);

  drawCombatPreviewPanel();
  buildButtons(); for (const b of buttons) drawButton(b);

  let ly = 552; drawText('ログ', PANEL_X + 16, ly, '#f0ead2', 18); ly += 26;
  for (const l of logs) { drawText(l, PANEL_X + 16, ly, '#e8e8e8', 14); ly += 20; }
  if (phase === 'result') { const msg = runCleared ? '浅層探索 完了' : '探索隊は撤退した'; drawText(msg, PANEL_X + 16, 284, runCleared ? '#a9ffb0' : '#ffb0b0', 24); }
}
function drawCombatPreviewPanel() {
  if (mode !== 'confirm-combat' || !pendingCombat) return;
  const preview = buildCombatPreview(pendingCombat);
  let y = 264;
  ctx.fillStyle = 'rgba(10, 14, 12, 0.55)'; ctx.fillRect(PANEL_X + 260, y - 24, 260, 164);
  ctx.strokeStyle = '#91b48e'; ctx.strokeRect(PANEL_X + 260, y - 24, 260, 164);
  drawText('戦闘予測', PANEL_X + 274, y, '#fff36a', 18); y += 26;
  for (const line of preview.lines) {
    const unavailable = !line.available;
    const cost = line.actor.team === 'player' ? ` 耐久-${line.durabilityCost}` : '';
    const text = unavailable ? `${line.label}: ${line.note}` : `${line.label}: ${line.damage} dmg / 命中${line.hit}%${cost}`;
    drawText(text, PANEL_X + 274, y, unavailable ? '#aaa' : '#fff', 13); y += 23;
  }
  drawText(`最大耐久消費: ${preview.totalDurabilityCost}`, PANEL_X + 274, y + 4, '#d8e7ff', 13);
}
function drawLevelUpPopup() {
  const popup = levelUpPopups[0]; if (!popup) return;
  ctx.fillStyle = 'rgba(0, 0, 0, 0.45)'; ctx.fillRect(0, 0, canvas.width, canvas.height);
  const w = 380, h = 190, x = MAP_X + (W * TILE - w) / 2, y = MAP_Y + 82;
  ctx.fillStyle = 'rgba(18, 24, 18, 0.96)'; ctx.fillRect(x, y, w, h); ctx.strokeStyle = '#f0ead2'; ctx.lineWidth = 2; ctx.strokeRect(x, y, w, h);
  drawText('LEVEL UP', x + 126, y + 38, '#fff36a', 24); drawText(`${popup.unitName}  Lv ${popup.level}`, x + 34, y + 72, '#ffffff', 18);
  popup.gains.forEach((g, i) => { const gx = x + 46 + (i % 3) * 108; const gy = y + 110 + Math.floor(i / 3) * 30; drawText(`${g.label} +${g.amount}`, gx, gy, '#cde6c7', 17); });
  const rest = levelUpPopups.length - 1; drawText(rest > 0 ? `クリックで次へ（残り ${rest}）` : 'クリックで閉じる', x + 118, y + h - 18, '#e8e8e8', 14);
}
function phaseLabel() { if (phase === 'world') return 'ワールド'; if (phase === 'player') return '自軍'; if (phase === 'enemy') return '敵軍'; if (phase === 'rest') return '休憩所'; return '結果'; }
function drawButton(b: Button) { ctx.fillStyle = b.disabled ? '#454545' : '#344d36'; ctx.fillRect(b.x, b.y, b.w, b.h); ctx.strokeStyle = '#91b48e'; ctx.strokeRect(b.x, b.y, b.w, b.h); drawText(b.label, b.x + 10, b.y + 23, b.disabled ? '#aaa' : '#fff', 14); }
function drawText(text: string, x: number, y: number, color: string, size: number) { ctx.fillStyle = color; ctx.font = `${size}px system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`; ctx.fillText(text, x, y); }

log('探索準備完了');
draw();
