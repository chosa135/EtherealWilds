type Team = 'player' | 'enemy';
type Tile = 'plain' | 'forest' | 'wall';
type Phase = 'player' | 'enemy' | 'rest' | 'result';
type Mode = 'idle' | 'move' | 'menu' | 'target-attack' | 'target-strong';
type StatKey = 'str' | 'mag' | 'skl' | 'spd' | 'def' | 'res';

type Weapon = {
  name: string;
  might: number;
  rangeMin: number;
  rangeMax: number;
  maxDurability: number;
  durability: number;
  kind: 'physical' | 'magic';
};

type Unit = {
  id: string;
  name: string;
  cls: string;
  team: Team;
  x: number;
  y: number;
  move: number;
  level: number;
  exp: number;
  hp: number;
  maxHp: number;
  str: number;
  mag: number;
  skl: number;
  spd: number;
  def: number;
  res: number;
  growth: Record<StatKey, number>;
  weapon: Weapon;
  potion: number;
  acted: boolean;
  unavailable: boolean;
  strongLeft: number;
};

type MapDef = { name: string; tiles: string[]; enemies: Unit[] };
type Button = { label: string; x: number; y: number; w: number; h: number; action: () => void; disabled?: boolean };

type Point = { x: number; y: number };
type LevelUpPopup = { unitName: string; level: number; gains: Array<{ label: string; amount: number }>; expiresAt: number };

const canvas = document.querySelector<HTMLCanvasElement>('#game')!;
const ctx = canvas.getContext('2d')!;

const TILE = 64;
const MAP_X = 28;
const MAP_Y = 28;
const PANEL_X = 720;
const PANEL_W = 430;
const W = 10;
const H = 9;

const statLabels: Record<StatKey, string> = {
  str: '力', mag: '魔力', skl: '技', spd: '速さ', def: '守備', res: '魔防',
};

const makeWeapon = (name: string, might: number, min: number, max: number, dura: number, kind: 'physical' | 'magic'): Weapon => ({
  name, might, rangeMin: min, rangeMax: max, maxDurability: dura, durability: dura, kind,
});

const cloneUnit = (u: Unit): Unit => ({ ...u, growth: { ...u.growth }, weapon: { ...u.weapon } });

const playerBase: Unit[] = [
  {
    id: 'p1', name: 'リュカ', cls: '剣士', team: 'player', x: 1, y: 4, move: 4, level: 1, exp: 0,
    hp: 24, maxHp: 24, str: 7, mag: 0, skl: 7, spd: 8, def: 4, res: 3,
    growth: { str: 2, mag: 0, skl: 3, spd: 4, def: 1, res: 1 },
    weapon: makeWeapon('鉄の剣', 5, 1, 1, 30, 'physical'), potion: 1, acted: false, unavailable: false, strongLeft: 2,
  },
  {
    id: 'p2', name: 'グレン', cls: '槍兵', team: 'player', x: 1, y: 5, move: 4, level: 1, exp: 0,
    hp: 28, maxHp: 28, str: 8, mag: 0, skl: 5, spd: 5, def: 7, res: 2,
    growth: { str: 2, mag: 0, skl: 2, spd: 2, def: 4, res: 1 },
    weapon: makeWeapon('鉄の槍', 6, 1, 1, 30, 'physical'), potion: 1, acted: false, unavailable: false, strongLeft: 2,
  },
  {
    id: 'p3', name: 'エナ', cls: '弓兵', team: 'player', x: 0, y: 4, move: 4, level: 1, exp: 0,
    hp: 21, maxHp: 21, str: 6, mag: 0, skl: 8, spd: 7, def: 3, res: 3,
    growth: { str: 2, mag: 0, skl: 4, spd: 3, def: 1, res: 1 },
    weapon: makeWeapon('鉄の弓', 5, 2, 2, 25, 'physical'), potion: 1, acted: false, unavailable: false, strongLeft: 2,
  },
  {
    id: 'p4', name: 'ミロ', cls: '魔道士', team: 'player', x: 0, y: 5, move: 4, level: 1, exp: 0,
    hp: 20, maxHp: 20, str: 0, mag: 7, skl: 6, spd: 6, def: 2, res: 6,
    growth: { str: 0, mag: 4, skl: 2, spd: 2, def: 1, res: 3 },
    weapon: makeWeapon('魔導書', 5, 1, 2, 25, 'magic'), potion: 1, acted: false, unavailable: false, strongLeft: 2,
  },
];

function enemy(id: string, name: string, cls: string, x: number, y: number, hp: number, str: number, mag: number, skl: number, spd: number, def: number, res: number, weapon: Weapon): Unit {
  return {
    id, name, cls, team: 'enemy', x, y, move: 3, level: 1, exp: 0,
    hp, maxHp: hp, str, mag, skl, spd, def, res,
    growth: { str: 0, mag: 0, skl: 0, spd: 0, def: 0, res: 0 }, weapon, potion: 0, acted: false, unavailable: false, strongLeft: 0,
  };
}

const maps: MapDef[] = [
  {
    name: '幽樹海・浅層入口',
    tiles: [
      '..........',
      '..ff......',
      '..f....f..',
      '.....##...',
      '..........',
      '...f......',
      '......ff..',
      '..........',
      '..........',
    ],
    enemies: [
      enemy('e1', '樹海の魔物', '魔物', 7, 2, 22, 7, 0, 4, 4, 4, 1, makeWeapon('爪', 4, 1, 1, 99, 'physical')),
      enemy('e2', 'ならず者', '斧兵', 8, 5, 24, 8, 0, 3, 3, 3, 1, makeWeapon('手斧', 6, 1, 1, 99, 'physical')),
      enemy('e3', '弓盗賊', '弓兵', 6, 6, 18, 6, 0, 5, 5, 2, 2, makeWeapon('粗末な弓', 4, 2, 2, 99, 'physical')),
    ],
  },
  {
    name: '幽樹海・苔むす小径',
    tiles: [
      '.....f....',
      '..fff.....',
      '...f..##..',
      '......#...',
      '.ff.......',
      '.f....ff..',
      '.....f....',
      '...##.....',
      '..........',
    ],
    enemies: [
      enemy('e4', '剣盗賊', '剣兵', 6, 1, 22, 7, 0, 5, 6, 4, 2, makeWeapon('粗末な剣', 4, 1, 1, 99, 'physical')),
      enemy('e5', '樹海の魔物', '魔物', 8, 2, 26, 8, 0, 4, 4, 5, 1, makeWeapon('爪', 5, 1, 1, 99, 'physical')),
      enemy('e6', '呪草', '魔物', 7, 6, 20, 0, 7, 5, 4, 2, 5, makeWeapon('瘴気', 5, 1, 2, 99, 'magic')),
      enemy('e7', '弓盗賊', '弓兵', 5, 7, 18, 6, 0, 5, 5, 2, 2, makeWeapon('粗末な弓', 4, 2, 2, 99, 'physical')),
    ],
  },
  {
    name: '幽樹海・幽金の露頭',
    tiles: [
      '..f.......',
      '..f..##...',
      '.....#....',
      '.ff.......',
      '.f....ff..',
      '.....f....',
      '...##.....',
      '..........',
      '.....f....',
    ],
    enemies: [
      enemy('e8', '樹海の魔物', '魔物', 6, 1, 26, 8, 0, 4, 5, 5, 2, makeWeapon('爪', 5, 1, 1, 99, 'physical')),
      enemy('e9', '斧盗賊', '斧兵', 8, 2, 25, 9, 0, 3, 4, 4, 1, makeWeapon('粗末な斧', 7, 1, 1, 99, 'physical')),
      enemy('e10', '弓盗賊', '弓兵', 7, 6, 19, 7, 0, 5, 5, 3, 2, makeWeapon('粗末な弓', 5, 2, 2, 99, 'physical')),
      enemy('e11', '幽金を喰らうもの', '強敵', 8, 7, 36, 10, 0, 6, 5, 7, 3, makeWeapon('大爪', 7, 1, 1, 99, 'physical')),
    ],
  },
];

let players = playerBase.map(cloneUnit);
let enemies: Unit[] = [];
let mapIndex = 0;
let phase: Phase = 'player';
let mode: Mode = 'idle';
let selected: Unit | null = null;
let selectedOrigin: Point | null = null;
let reachable: Point[] = [];
let targets: Unit[] = [];
let buttons: Button[] = [];
let logs: string[] = [];
let currentTiles: Tile[][] = [];
let hover: Point | null = null;
let runCleared = false;
let levelUpPopups: LevelUpPopup[] = [];

function log(msg: string) {
  logs.unshift(msg);
  logs = logs.slice(0, 9);
}

function parseTiles(def: MapDef): Tile[][] {
  return def.tiles.map(row => row.split('').map(c => c === 'f' ? 'forest' : c === '#' ? 'wall' : 'plain'));
}

function startMap(index: number) {
  mapIndex = index;
  currentTiles = parseTiles(maps[index]);
  enemies = maps[index].enemies.map(cloneUnit);
  const starts = [{ x: 1, y: 4 }, { x: 1, y: 5 }, { x: 0, y: 4 }, { x: 0, y: 5 }];
  players.forEach((p, i) => {
    p.x = starts[i].x;
    p.y = starts[i].y;
    p.acted = p.unavailable;
    p.strongLeft = 2;
  });
  phase = 'player';
  mode = 'idle';
  selected = null;
  selectedOrigin = null;
  reachable = [];
  log(`【${maps[index].name}】探索開始`);
}

function inBounds(x: number, y: number) { return x >= 0 && y >= 0 && x < W && y < H; }
function tileAt(x: number, y: number) { return currentTiles[y]?.[x] ?? 'wall'; }
function moveCost(x: number, y: number) { const t = tileAt(x, y); return t === 'wall' ? 999 : t === 'forest' ? 2 : 1; }
function livingPlayers() { return players.filter(u => !u.unavailable && u.hp > 0); }
function activePlayers() { return livingPlayers().filter(u => !u.acted); }
function livingEnemies() { return enemies.filter(u => u.hp > 0); }
function allUnits() { return [...livingPlayers(), ...livingEnemies()]; }
function unitAt(x: number, y: number): Unit | null { return allUnits().find(u => u.x === x && u.y === y) ?? null; }
function distance(a: Point, b: Point) { return Math.abs(a.x - b.x) + Math.abs(a.y - b.y); }
function pointKey(p: Point) { return `${p.x},${p.y}`; }
function inRange(attacker: Unit, target: Unit) { const d = distance(attacker, target); return d >= attacker.weapon.rangeMin && d <= attacker.weapon.rangeMax; }

function computeAttackCellsFromPositions(u: Unit, positions: Point[]): Point[] {
  const cells = new Map<string, Point>();
  for (const pos of positions) {
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      if (tileAt(x, y) === 'wall') continue;
      const d = distance(pos, { x, y });
      if (d >= u.weapon.rangeMin && d <= u.weapon.rangeMax) cells.set(`${x},${y}`, { x, y });
    }
  }
  return [...cells.values()];
}

function getPreviewRanges(u: Unit, allowMove: boolean) {
  const moveCells = allowMove ? computeReachable(u) : [{ x: u.x, y: u.y }];
  const moveSet = new Set(moveCells.map(pointKey));
  const attackCells = computeAttackCellsFromPositions(u, moveCells).filter(p => !moveSet.has(pointKey(p)));
  return { moveCells, attackCells };
}

function computeReachable(u: Unit): Point[] {
  const seen = new Map<string, number>();
  const queue: Array<{ x: number; y: number; cost: number }> = [{ x: u.x, y: u.y, cost: 0 }];
  seen.set(`${u.x},${u.y}`, 0);
  while (queue.length) {
    const cur = queue.shift()!;
    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nx = cur.x + dx, ny = cur.y + dy;
      if (!inBounds(nx, ny) || tileAt(nx, ny) === 'wall') continue;
      const occ = unitAt(nx, ny);
      if (occ && occ.id !== u.id) continue;
      const nextCost = cur.cost + moveCost(nx, ny);
      if (nextCost > u.move) continue;
      const key = `${nx},${ny}`;
      if (!seen.has(key) || nextCost < seen.get(key)!) {
        seen.set(key, nextCost);
        queue.push({ x: nx, y: ny, cost: nextCost });
      }
    }
  }
  return [...seen.keys()].map(k => { const [x, y] = k.split(',').map(Number); return { x, y }; });
}

function canStand(x: number, y: number) { return reachable.some(p => p.x === x && p.y === y); }
function isPlayer(u: Unit | null): u is Unit { return !!u && u.team === 'player'; }

function attackPower(u: Unit, strong: boolean) {
  const base = u.weapon.kind === 'magic' ? u.mag : u.str;
  return base + u.weapon.might + (strong ? 5 : 0);
}
function defenseAgainst(attacker: Unit, defender: Unit) { return attacker.weapon.kind === 'magic' ? defender.res : defender.def; }
function strikeDamage(attacker: Unit, defender: Unit, strong: boolean) { return Math.max(1, attackPower(attacker, strong) - defenseAgainst(attacker, defender)); }
function canUseWeapon(u: Unit, strong: boolean) { return u.weapon.durability >= (strong ? 3 : 1); }

function addExp(u: Unit, amount: number) {
  if (u.team !== 'player' || u.unavailable) return;
  u.exp += amount;
  while (u.exp >= 100) {
    u.exp -= 100;
    levelUp(u);
  }
}

function weightedStat(growth: Record<StatKey, number>): StatKey {
  const entries = Object.entries(growth) as Array<[StatKey, number]>;
  const total = entries.reduce((s, [, w]) => s + Math.max(0, w), 0);
  let r = Math.random() * total;
  for (const [k, w] of entries) {
    r -= Math.max(0, w);
    if (r <= 0) return k;
  }
  return 'str';
}

function levelUp(u: Unit) {
  u.level += 1;
  u.maxHp += 1;
  u.hp += 1;
  const gains: Partial<Record<StatKey, number>> = {};
  for (let i = 0; i < 3; i++) {
    const k = weightedStat(u.growth);
    u[k] += 1;
    gains[k] = (gains[k] ?? 0) + 1;
  }
  const gainedStats = Object.entries(gains).map(([k, v]) => ({ label: statLabels[k as StatKey], amount: v as number }));
  const text = gainedStats.map(g => `${g.label}+${g.amount}`).join(' / ');
  log(`${u.name} Lv${u.level}: HP+1 / ${text}`);
  levelUpPopups.push({
    unitName: u.name,
    level: u.level,
    gains: [{ label: 'HP', amount: 1 }, ...gainedStats],
    expiresAt: Date.now() + 2800,
  });
  levelUpPopups = levelUpPopups.slice(-4);
}

function doCombat(attacker: Unit, defender: Unit, strong: boolean) {
  if (!canUseWeapon(attacker, strong)) {
    log(`${attacker.name}の武器耐久が足りない`);
    return;
  }
  if (strong && attacker.team === 'player') attacker.strongLeft -= 1;
  consumeDurability(attacker, strong ? 3 : 1);
  const hits = attacker.spd >= defender.spd + 4 ? 2 : 1;
  for (let i = 0; i < hits && defender.hp > 0; i++) {
    const dmg = strikeDamage(attacker, defender, strong);
    defender.hp = Math.max(0, defender.hp - dmg);
    log(`${attacker.name}の${strong ? '強撃' : '攻撃'}: ${defender.name}に${dmg}ダメージ`);
  }
  if (defender.hp <= 0) {
    defeatUnit(defender, attacker);
  } else if (inRange(defender, attacker) && canUseWeapon(defender, false)) {
    consumeDurability(defender, 1);
    const counterHits = defender.spd >= attacker.spd + 4 ? 2 : 1;
    for (let i = 0; i < counterHits && attacker.hp > 0; i++) {
      const dmg = strikeDamage(defender, attacker, false);
      attacker.hp = Math.max(0, attacker.hp - dmg);
      log(`${defender.name}の反撃: ${attacker.name}に${dmg}ダメージ`);
    }
    if (attacker.hp <= 0) defeatUnit(attacker, defender);
  }
  if (attacker.team === 'player') addExp(attacker, 5);
  if (defender.hp <= 0 && attacker.team === 'player') addExp(attacker, 30);
  checkMapEnd();
}

function consumeDurability(u: Unit, amount: number) {
  if (u.team === 'player') u.weapon.durability = Math.max(0, u.weapon.durability - amount);
}

function defeatUnit(unit: Unit, by: Unit) {
  if (unit.team === 'player') {
    unit.unavailable = true;
    unit.acted = true;
    log(`${unit.name}は戦闘不可になり、後方へ撤退した`);
  } else {
    log(`${unit.name}を撃破した`);
  }
}

function finishAction() {
  if (selected) selected.acted = true;
  selected = null;
  selectedOrigin = null;
  reachable = [];
  targets = [];
  mode = 'idle';
  if (phase === 'player' && activePlayers().length === 0) beginEnemyTurn();
}

function beginEnemyTurn() {
  phase = 'enemy';
  mode = 'idle';
  selected = null;
  selectedOrigin = null;
  setTimeout(runEnemyTurn, 250);
}

function runEnemyTurn() {
  for (const e of livingEnemies()) {
    const targetsNow = livingPlayers();
    if (targetsNow.length === 0) break;
    let target = targetsNow.filter(p => inRange(e, p)).sort((a, b) => a.hp - b.hp)[0];
    if (!target) {
      moveEnemyToward(e, targetsNow);
      target = targetsNow.filter(p => inRange(e, p)).sort((a, b) => a.hp - b.hp)[0];
    }
    if (target) doCombat(e, target, false);
  }
  if (phase !== 'result' && phase !== 'rest') {
    livingPlayers().forEach(p => { p.acted = false; p.strongLeft = 2; });
    phase = 'player';
    log('自軍フェイズ');
  }
}

function moveEnemyToward(e: Unit, targetsNow: Unit[]) {
  const reach = computeReachable(e);
  const occupied = new Set(allUnits().filter(u => u.id !== e.id).map(u => `${u.x},${u.y}`));
  let best = { x: e.x, y: e.y };
  let bestScore = 999;
  for (const p of reach) {
    if (occupied.has(`${p.x},${p.y}`)) continue;
    const score = Math.min(...targetsNow.map(t => distance(p, t)));
    if (score < bestScore) { best = p; bestScore = score; }
  }
  e.x = best.x; e.y = best.y;
}

function checkMapEnd() {
  if (livingEnemies().length === 0) {
    log(`【${maps[mapIndex].name}】敵全滅`);
    livingPlayers().forEach(p => { p.hp = Math.min(p.maxHp, p.hp + 8); });
    if (mapIndex < maps.length - 1) {
      phase = 'rest';
      mode = 'idle';
      selected = null;
      selectedOrigin = null;
    } else {
      phase = 'result';
      runCleared = true;
      log('幽樹海・浅層探索 完了');
    }
  } else if (livingPlayers().length === 0) {
    phase = 'result';
    runCleared = false;
    log('探索隊は撤退した');
  }
}

function chooseRest(action: 'repair' | 'rescue' | 'train') {
  if (action === 'repair') {
    for (const p of players) {
      const recover = Math.ceil(p.weapon.maxDurability * 0.3);
      p.weapon.durability = Math.min(p.weapon.maxDurability, p.weapon.durability + recover);
    }
    log('休憩所: 全員の武器を修繕した');
  }
  if (action === 'rescue') {
    const target = players.find(p => p.unavailable);
    if (target) {
      target.unavailable = false;
      target.hp = Math.max(1, Math.ceil(target.maxHp * 0.5));
      log(`休憩所: ${target.name}を救護し復帰させた`);
    } else {
      log('救護が必要な隊員はいない');
      return;
    }
  }
  if (action === 'train') {
    for (const p of livingPlayers()) addExp(p, 20);
    log('休憩所: 出撃可能な全員が鍛錬した');
  }
  startMap(mapIndex + 1);
}

function cancelSelection() {
  if (selected && selectedOrigin) {
    selected.x = selectedOrigin.x;
    selected.y = selectedOrigin.y;
  }
  selected = null;
  selectedOrigin = null;
  reachable = [];
  targets = [];
  mode = 'idle';
  log('選択を解除した');
}

function returnToMenu() {
  targets = [];
  mode = 'menu';
}

function usePotion(u: Unit) {
  if (u.potion <= 0) { log('傷薬がない'); return; }
  if (u.hp >= u.maxHp) { log('HPは満タン'); return; }
  u.potion -= 1;
  u.hp = Math.min(u.maxHp, u.hp + 10);
  log(`${u.name}は傷薬で回復した`);
  finishAction();
}

function buildButtons() {
  buttons = [];
  const bx = PANEL_X + 16;
  let by = 360;
  const add = (label: string, action: () => void, disabled = false) => {
    buttons.push({ label, x: bx, y: by, w: 180, h: 38, action, disabled });
    by += 46;
  };
  if (phase === 'rest') {
    const hasDown = players.some(p => p.unavailable);
    add('修繕：武器耐久+30%', () => chooseRest('repair'));
    add('救護：戦闘不可を1人復帰', () => chooseRest('rescue'), !hasDown);
    add('鍛錬：出撃可能者 EXP+20', () => chooseRest('train'));
    return;
  }
  if (phase === 'result') {
    add('最初から遊ぶ', () => resetRun());
    return;
  }
  if (mode === 'move' && selected) {
    add('やめる', () => cancelSelection());
  }
  if (mode === 'menu' && selected) {
    const attackable = livingEnemies().some(e => inRange(selected!, e));
    add('攻撃', () => selectTargets(false), !attackable || !canUseWeapon(selected, false));
    add(`強撃 ${selected.strongLeft}/2`, () => selectTargets(true), !attackable || selected.strongLeft <= 0 || !canUseWeapon(selected, true));
    add(`傷薬 ${selected.potion}`, () => usePotion(selected!), selected.potion <= 0 || selected.hp >= selected.maxHp);
    add('待機', () => finishAction());
    add('やめる', () => cancelSelection());
  }
  if ((mode === 'target-attack' || mode === 'target-strong') && selected) {
    add('やめる', () => returnToMenu());
  }
}

function selectTargets(strong: boolean) {
  if (!selected) return;
  targets = livingEnemies().filter(e => inRange(selected!, e));
  mode = strong ? 'target-strong' : 'target-attack';
  log('攻撃対象を選択してください');
}

function resetRun() {
  players = playerBase.map(cloneUnit);
  logs = [];
  startMap(0);
}

function screenToCell(mx: number, my: number): Point | null {
  const x = Math.floor((mx - MAP_X) / TILE);
  const y = Math.floor((my - MAP_Y) / TILE);
  return inBounds(x, y) ? { x, y } : null;
}

canvas.addEventListener('mousemove', e => {
  const rect = canvas.getBoundingClientRect();
  hover = screenToCell(e.clientX - rect.left, e.clientY - rect.top);
});

canvas.addEventListener('click', e => {
  const rect = canvas.getBoundingClientRect();
  const mx = e.clientX - rect.left;
  const my = e.clientY - rect.top;
  for (const b of buttons) {
    if (mx >= b.x && mx <= b.x + b.w && my >= b.y && my <= b.y + b.h) {
      if (!b.disabled) b.action();
      return;
    }
  }
  if (phase !== 'player') return;
  const cell = screenToCell(mx, my);
  if (!cell) return;
  const u = unitAt(cell.x, cell.y);
  if (mode === 'idle') {
    if (isPlayer(u) && !u.acted && !u.unavailable) {
      selected = u;
      selectedOrigin = { x: u.x, y: u.y };
      reachable = computeReachable(u);
      mode = 'move';
      log(`${u.name}を選択`);
    }
    return;
  }
  if (mode === 'move') {
    if (canStand(cell.x, cell.y) && selected) {
      selected.x = cell.x; selected.y = cell.y;
      mode = 'menu';
      return;
    }
    cancelSelection();
    return;
  }
  if ((mode === 'target-attack' || mode === 'target-strong') && selected) {
    const target = targets.find(t => t.x === cell.x && t.y === cell.y);
    if (target) {
      doCombat(selected, target, mode === 'target-strong');
      finishAction();
    } else {
      returnToMenu();
    }
  }
});

function draw() {
  ctx.fillStyle = '#151916';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  drawMap();
  drawUnits();
  drawPanel();
  drawLevelUpPopups();
  requestAnimationFrame(draw);
}

function drawMap() {
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const sx = MAP_X + x * TILE, sy = MAP_Y + y * TILE;
    const t = tileAt(x, y);
    ctx.fillStyle = t === 'forest' ? '#29452d' : t === 'wall' ? '#4a4a4a' : '#253326';
    ctx.fillRect(sx, sy, TILE, TILE);
    ctx.strokeStyle = '#556052'; ctx.strokeRect(sx, sy, TILE, TILE);
    if (t === 'forest') drawText('森', sx + 20, sy + 38, '#cfe8ca', 16);
    if (t === 'wall') drawText('岩', sx + 20, sy + 38, '#ddd', 16);
  }
  drawRangePreview();
  if (mode === 'target-attack' || mode === 'target-strong') {
    for (const t of targets) overlayCell(t.x, t.y, 'rgba(255,90,80,0.42)');
  }
  if (hover) overlayCell(hover.x, hover.y, 'rgba(255,255,255,0.12)');
}

function drawRangePreview() {
  const hoverUnit = hover ? unitAt(hover.x, hover.y) : null;
  const previewUnit = selected ?? hoverUnit;
  if (!previewUnit || previewUnit.unavailable || previewUnit.hp <= 0) return;

  const allowMove = selected?.id === previewUnit.id
    ? mode === 'move'
    : true;

  const ranges = selected?.id === previewUnit.id && mode === 'move'
    ? {
        moveCells: reachable,
        attackCells: computeAttackCellsFromPositions(previewUnit, reachable).filter(p => !new Set(reachable.map(pointKey)).has(pointKey(p))),
      }
    : getPreviewRanges(previewUnit, allowMove);

  for (const p of ranges.attackCells) overlayCell(p.x, p.y, 'rgba(255,90,80,0.23)');
  for (const p of ranges.moveCells) overlayCell(p.x, p.y, 'rgba(80,150,255,0.28)');
}

function overlayCell(x: number, y: number, color: string) {
  ctx.fillStyle = color;
  ctx.fillRect(MAP_X + x * TILE, MAP_Y + y * TILE, TILE, TILE);
}

function drawUnits() {
  for (const u of [...livingEnemies(), ...livingPlayers()]) {
    const sx = MAP_X + u.x * TILE + TILE / 2;
    const sy = MAP_Y + u.y * TILE + TILE / 2;
    ctx.beginPath();
    ctx.arc(sx, sy, 22, 0, Math.PI * 2);
    ctx.fillStyle = u.team === 'player' ? '#7fb7ff' : '#ff7f7f';
    ctx.fill();
    ctx.strokeStyle = selected?.id === u.id ? '#fff36a' : '#101010';
    ctx.lineWidth = selected?.id === u.id ? 4 : 2;
    ctx.stroke();
    drawText(u.name.slice(0, 2), sx - 16, sy + 5, '#111', 14);
    const barW = 46;
    ctx.fillStyle = '#222'; ctx.fillRect(sx - barW / 2, sy + 27, barW, 6);
    ctx.fillStyle = '#66e083'; ctx.fillRect(sx - barW / 2, sy + 27, barW * (u.hp / u.maxHp), 6);
    drawText(`${u.hp}`, sx - 10, sy + 48, '#fff', 12);
    if (u.acted && u.team === 'player') {
      ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.arc(sx, sy, 23, 0, Math.PI * 2); ctx.fill();
    }
  }
}

function drawPanel() {
  ctx.fillStyle = '#20271f';
  ctx.fillRect(PANEL_X, 0, PANEL_W, canvas.height);
  drawText('Ethereal Wilds Prototype', PANEL_X + 16, 32, '#f0ead2', 22);
  drawText(`${maps[mapIndex].name}`, PANEL_X + 16, 62, '#cde6c7', 16);
  drawText(`フェイズ: ${phaseLabel()}`, PANEL_X + 16, 88, '#ffffff', 16);

  const info = selected ?? (hover ? unitAt(hover.x, hover.y) ?? null : null);
  let y = 124;
  if (info) {
    drawText(`${info.name} / ${info.cls}`, PANEL_X + 16, y, '#fff36a', 20); y += 28;
    drawText(`Lv${info.level} EXP${info.exp}  HP ${info.hp}/${info.maxHp}`, PANEL_X + 16, y, '#fff', 16); y += 24;
    drawText(`力${info.str} 魔${info.mag} 技${info.skl} 速${info.spd}`, PANEL_X + 16, y, '#fff', 16); y += 24;
    drawText(`守${info.def} 魔防${info.res} 移${info.move}`, PANEL_X + 16, y, '#fff', 16); y += 24;
    drawText(`${info.weapon.name} 威力${info.weapon.might} 射程${info.weapon.rangeMin}-${info.weapon.rangeMax}`, PANEL_X + 16, y, '#d8e7ff', 16); y += 24;
    drawText(`耐久 ${info.weapon.durability}/${info.weapon.maxDurability}  強撃 ${info.strongLeft}/2`, PANEL_X + 16, y, '#d8e7ff', 16); y += 24;
    if (info.unavailable) drawText('状態: 戦闘不可', PANEL_X + 16, y, '#ff9b9b', 16);
  } else {
    drawText('自軍ユニットを選択してください', PANEL_X + 16, y, '#ddd', 16);
  }

  buildButtons();
  for (const b of buttons) drawButton(b);

  let ly = 570;
  drawText('ログ', PANEL_X + 16, ly, '#f0ead2', 18);
  ly += 26;
  for (const l of logs) { drawText(l, PANEL_X + 16, ly, '#e8e8e8', 14); ly += 20; }

  if (phase === 'result') {
    const msg = runCleared ? '浅層探索 完了' : '探索隊は撤退した';
    drawText(msg, PANEL_X + 16, 320, runCleared ? '#a9ffb0' : '#ffb0b0', 24);
  }
}

function drawLevelUpPopups() {
  const now = Date.now();
  levelUpPopups = levelUpPopups.filter(p => p.expiresAt > now);
  if (levelUpPopups.length === 0) return;
  const popup = levelUpPopups[levelUpPopups.length - 1];
  const w = 360;
  const h = 170;
  const x = MAP_X + (W * TILE - w) / 2;
  const y = MAP_Y + 70;

  ctx.fillStyle = 'rgba(18, 24, 18, 0.94)';
  ctx.fillRect(x, y, w, h);
  ctx.strokeStyle = '#f0ead2';
  ctx.lineWidth = 2;
  ctx.strokeRect(x, y, w, h);
  drawText('LEVEL UP', x + 116, y + 34, '#fff36a', 24);
  drawText(`${popup.unitName}  Lv ${popup.level}`, x + 32, y + 66, '#ffffff', 18);

  const cols = 3;
  popup.gains.forEach((g, i) => {
    const gx = x + 42 + (i % cols) * 102;
    const gy = y + 100 + Math.floor(i / cols) * 30;
    drawText(`${g.label} +${g.amount}`, gx, gy, '#cde6c7', 17);
  });
}

function phaseLabel() {
  if (phase === 'player') return '自軍';
  if (phase === 'enemy') return '敵軍';
  if (phase === 'rest') return '休憩所';
  return '結果';
}

function drawButton(b: Button) {
  ctx.fillStyle = b.disabled ? '#454545' : '#344d36';
  ctx.fillRect(b.x, b.y, b.w, b.h);
  ctx.strokeStyle = '#91b48e'; ctx.strokeRect(b.x, b.y, b.w, b.h);
  drawText(b.label, b.x + 10, b.y + 25, b.disabled ? '#aaa' : '#fff', 15);
}

function drawText(text: string, x: number, y: number, color: string, size: number) {
  ctx.fillStyle = color;
  ctx.font = `${size}px system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`;
  ctx.fillText(text, x, y);
}

startMap(0);
draw();
